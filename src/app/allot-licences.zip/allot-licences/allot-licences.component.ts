import { Component, OnInit, ViewChild,ElementRef  } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray,AbstractControl, ValidationErrors,FormGroupDirective, NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Observable } from 'rxjs';
import { ActivatedRoute, Params, Router } from '@angular/router'
import { NgZone } from '@angular/core';
import { debounceTime, map, flatMap } from 'rxjs/operators';

@Component({
  selector: 'app-allot-licences',
  templateUrl: './allot-licences.component.html',
  styleUrls: ['./allot-licences.component.css']
})
export class AllotLicencesComponent implements OnInit {
  @ViewChild('closebutton') closebutton;
  @ViewChild('fileInput') fileInput;
  @ViewChild('adminclose') adminclose;
  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;

  CompanyForm: FormGroup;
  StoreForm: FormGroup;
  AdminForm: FormGroup;
  CompanySubmitted = false;
  StoreSubmitted = false;
  AdminSubmitted = false;
  SubscriptionSubmitted = false;
  preview: string;
  Companies = [];
  Stores = [];
  PurchasedProducts = [];
  AdminData = [];
  emailerror = '';
  subscriptionData: FormArray;;
   SubscriptionForm: FormGroup 
   companymessage = ''
   storemessage = ''
    adminmessage = ''
    countries = [];
    states = [];
    storehide = false;

  constructor(private fb: FormBuilder,private userService: UserService,private Router: Router,private zone: NgZone ) { }

  ngOnInit(): void {
    document.body.classList.add('orderbg');
 
    this.dropdownrefresh();
     this.AdminRefresh()  


   this.userService.UserPurchasedProducts().subscribe((res)=>{
 

   this.PurchasedProducts = res.purchased_products;
console.log(this.PurchasedProducts)
   this.SubscriptionForm.setControl('subscriptionData',this.setExistingStore( res.purchased_products));

 })

 this.userService.getcountries().subscribe((data: any) => {
  this.countries = data.countries;
})


    this.CompanyForm = this.fb.group({
      // company_id: [''],
      company_name: ['',Validators.required],
      owner_name: ['',Validators.required],
      contact_number: ['',Validators.required],
      email: ['',[Validators.required,Validators.email]],
      address_line1: ['',Validators.required],
      address_line2: [''],
      Country:[null,Validators.required],
      city: ['',Validators.required],
      State: ['',Validators.required],
      zip: ['',Validators.required],
     
    });    

    this.StoreForm = this.fb.group({
      Storeimage: [null],
       store_name: [null,Validators.required],
       owner_name: [null,Validators.required],
       contact_number: [null,Validators.required],
       email:['',[Validators.required,Validators.email]],
       address_line1: [null,Validators.required],
       address_line2: [null],
       Country:[null,Validators.required],
       city: [null,Validators.required],
       State: [null,Validators.required],
       zip: [null,Validators.required],
    })

     this.AdminForm = this.fb.group({
       firstname: ['',Validators.required],
       lastname:['',Validators.required],
       email:['',[Validators.required,Validators.email],this.validateNameViaServer.bind(this)]


     })

    this.SubscriptionForm = this.fb.group({
    subscriptionData:this.fb.array([
      this.fb.group({
                SubscriptionId: [''],
              company_id: [Validators.required],
              store_id: ['',Validators.required],
              admin_id: ['',Validators.required]
            })
    ]), 

  });
  }

  setExistingStore(skillSets): FormArray {
    const formArray = new FormArray([]);
    skillSets.forEach(s => {
      formArray.push(this.fb.group({
        SubscriptionId:s.product_id,
        company_id:new FormControl([]),
        store_id: new FormControl([]),
        admin_id: new FormControl([])
        
      }));
    });
    return formArray;


  }
  CompanyResetValidation() {
    this.CompanyForm.reset()
  }

CompanyReset(){
  this.CompanyForm.reset()
  this.CompanySubmitted = false;
}

 StoreReset(){
  this.StoreForm.reset()
 this.StoreSubmitted = false;
 } 

 AdminReset(){
  this.AdminForm.reset()
 this.AdminSubmitted = false;
  
}

  get StoreArray(): FormArray {
   
    return <FormArray>this.SubscriptionForm.get('subscriptionData');
    
  }

  

  ngOnDestroy(): void {
    document.body.classList.remove('orderbg');
  }

dropdownrefresh(){
  this.userService.getUserCompanies().subscribe((res)=>{
    this.Companies = res.companies;
     // console.log(res);
   })
}

storeRefresh(){
const companyid = localStorage.getItem('company_id');

this.userService.getUserStores(companyid).subscribe((res)=>{
  //  console.log(res);
   this.Stores = res.stores
})   


}

AdminRefresh(){
this.userService.getAdminUsers().subscribe((res)=>{
    //  console.log(res);
     this.AdminData = res.admin_users;
   })

}

changeState(event) {
  console.log(event);
  localStorage.setItem('country.id', event);
  this.userService.getRegions(event).subscribe(res => {
    this.states = res.regions;
  })

}

  SelectedCompany(event,subId){
    console.log(event);
    
   localStorage.setItem('Company_id', event); 
   this.userService.getUserStores(event).subscribe((res)=>{
     this.storehide = true
   this.Stores[subId] = res.stores
})   
  }


  get f() { return this.CompanyForm.controls; };
  get C() { return this.StoreForm.controls; };
  get k(){ return this.AdminForm.controls;};
  get v(){ return this.StoreArray.controls;};



  uploadFile(event) {
    const file = (event.target as HTMLInputElement).files[0];
    

    // File Preview
    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.preview = reader.result as string;
   
    this.StoreForm.patchValue({
      Storeimage: e.target.result
    });
  }
    this.StoreForm.get('Storeimage').updateValueAndValidity()
    reader.readAsDataURL(file)
  }

  Submit() {
    this.CompanySubmitted = true;

    // stop here if form is invalid
    if (this.CompanyForm.invalid) {
        return;
    }
    this.userService.addNewCompany(this.CompanyForm.value,).subscribe(res=>{
      console.log(res);
      if(res.status == 1){
        this.companymessage = 'Your Company  is Created!';
        setTimeout(() =>  this.companymessage = '', 2000)
        setTimeout(() =>  this.closebutton.nativeElement.click(), 2000)
        this.dropdownrefresh();
      }
     
    })   
}

onSubmit(){
  this.StoreSubmitted = true;
console.log(this.StoreForm.value)
  // stop here if form is invalid
  if (this.StoreForm.invalid) {
      return;
  }

  this.userService.addNewStore(this.StoreForm.value).subscribe(res=>{
    console.log(res);
    if(res.status == 1){
      localStorage.setItem('company_id',res.company_id);
      this.storemessage = 'Your Store  is Created!';
      setTimeout(() =>  this.storemessage = '', 2000)
      setTimeout(() =>  this.fileInput.nativeElement.click(), 2000)
        this.storeRefresh();
    }
   
  })   

}

AdminSubmit(){
this.AdminSubmitted = true;

if (this.AdminForm.invalid) {
  return;
}
 
this.userService.createAdminUser(this.AdminForm.value).subscribe((res)=>{
  console.log(res);

  if(res.status == 1){
    this.AdminRefresh();
    this.adminmessage = 'Your Admin  is Created!';
    setTimeout(() =>  this.adminmessage = '', 2000)
    setTimeout(() =>  this.adminclose.nativeElement.click(), 2000)
   
  }
  this.emailerror = res.validationErrors.email
  console.log(this.emailerror);
})

}

validateNameViaServer({value}: AbstractControl): Observable<ValidationErrors | null> {
  return this.userService.isEmailRegisterd(value)
    .pipe(debounceTime(500), map((res) => {
      console.log(status);
      if (res.status == 2) {
        return {
          isExists:true
        };
      }
      return null;
    }));
}

// allotLicenseFormValid = false;
// checkFormValid ( formValues) {
//     let vals = formValues.subscriptionData;
//     this.allotLicenseFormValid = true;
//     for(let msg of vals){
//         if (msg.SubscriptionId <= 0 || msg.company_id <= 0 || msg.store_id <= 0 || msg.admin_id <= 0) {
//           this.allotLicenseFormValid = false;
//         }
//     }
// }

Finish(){
  this. SubscriptionSubmitted = false;
  // console.log(this.PurchasedProducts);
  if (this.SubscriptionForm.invalid) { 
    return;
}
this.SubscriptionSubmitted = true;
console.log(this.SubscriptionForm.value);

 this.userService.updateCustomerSubscription(this.SubscriptionForm.value).subscribe((res)=>{

  console.log(res);
  // if(res.status == 1  ){
  //   this.zone.run(() => this.Router.navigate(['/subscriptions']));

  // }
 })

}

}
