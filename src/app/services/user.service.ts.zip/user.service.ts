import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../checkout/checkout.model'

@Injectable({
  providedIn: 'root'
})
export class UserService {
  user_id = '';
  constructor(private httpClient: HttpClient) { }

  api_url = 'http://3.17.222.150/nuflorist-backend/api';

  loginRequest(email, password) {
    return this.httpClient.post<any>(this.api_url + '/login', { email, password });
  }

  passwordReset(password, confirmPassword) {
    return this.httpClient.post<any>(this.api_url + '/passwordReset', { password, confirmPassword });
  }

  forgotPassword(email) {
    return this.httpClient.post<any>(this.api_url + '/forgotpassword', { email });
  }

  signupRequest(email, password) {
    return this.httpClient.post<any>(this.api_url + '/register', { email, password });
  }

  getAllProducts() {
    return this.httpClient.post<any>(this.api_url + '/getProductsList', {});
  }

  getcountries() {
    return this.httpClient.post<any>(this.api_url + '/getCountries', {});
  }

  getRegions(country_id) {
    return this.httpClient.post<any>(this.api_url + '/getRegions', { country_id });
  }

  getCities(country_id, region_id) {
    return this.httpClient.post<any>(this.api_url + '/getCities', { country_id, region_id })
  }

  GetProductbyId(product_id) {
    return this.httpClient.post<any>(this.api_url + '/getProductInfo', { product_id })
  }

  custmoreRegister(email, password, mobile_no, first_name, address_line1, city, country, state, zip, needValidation) {

    let filterProducts = JSON.parse(localStorage.getItem("FilterProduct"));

    if(localStorage.getItem('nu_c_user_id') !== null){
       var user_id =  localStorage.getItem('nu_c_user_id');
    }
    
    return this.httpClient.post<any>(this.api_url + '/customerRegister', { email, password, mobile_no, first_name, address_line1, city, country, state, zip, needValidation, filterProducts,user_id });
  }

  custmoreRegisterFinal(customre, StripeToken, Card_id) {

    if(localStorage.getItem('nu_c_user_id') !== null){
      var user_id =  localStorage.getItem('nu_c_user_id');
   } 
    let filterProducts = JSON.parse(localStorage.getItem("FilterProduct"));

    let TotalAmount = JSON.parse(localStorage.getItem('OverallTotal'))

    let AllData = {
      "customre":customre,
      "StripeToken":StripeToken,
      "Card_id":Card_id,
      "filterProducts":filterProducts,
      "TotalAmount":TotalAmount,
      "user_id":user_id
    };
    console.log(AllData);

    return this.httpClient.post<any>(this.api_url + '/customerRegisterFinal', { AllData });
  }

}
